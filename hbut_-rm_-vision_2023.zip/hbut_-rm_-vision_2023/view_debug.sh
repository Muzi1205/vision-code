source /opt/ros/galactic/setup.bash
source install/setup.bash
ros2 launch bringup view_launch.py